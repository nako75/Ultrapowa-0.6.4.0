Ultrapowa Clash Server (UCS) v.0.6.4.0:

This package contains a CoC Server Emulator in beta version.
More Details: http://www.ultrapowa.com
Help and Support: http://ultrapowa.com/forum/
Youtube Channel: https://www.youtube.com/channel/UCWJz5XMkObpGGmEUsnjTq1w
Source code: https://github.com/Ultrapowa/UCS

Ultrapowa Clash Server License:

1. Permission is hereby granted to use and copy this package, provided that:
	* any distribution of this package, wether modified or not, is strictly forbidden
	* this package is for non-commercial use only (contact ultrapowa.exp@gmail.com for commercial purpose)

THIS PACKAGE IS PROVIDED "AS IS" AND WITHOUT WARRANTY. ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE AUTHORS BE LIABLE TO ANY PARTY FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES ARISING IN ANY WAY OUT OF THE USE OF THIS PACKAGE.